from django.urls import path

from .import views as v

urlpatterns = [
    path("", v.home),
    path("register", v.register),
    path("register2", v.formregister)
]