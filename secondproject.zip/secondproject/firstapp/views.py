from django.shortcuts import HttpResponse

def home(r):
    string="""
    <h4>WELCOME TO HOME PAGE</h4><br>
    <a href="person">person</a><br>
    <a href="person1">person1</a><br>
     <a href="person2">person2</a>
    """
    return HttpResponse(string)

def person(k):
    string ="""
    <i>Person method</i><br>
    <a href="/">home page</a><br>
    <a href="person1"> another person</a>
    """
    return HttpResponse(string)

def person1(r):
    string = """"
    <i>Person1 method</i><br>
    <a href="person">Person</a>
    """
    return HttpResponse(string)

def person2(r):
    string = """"
    <i>Person2 method</i><br>
    <a href="person">Person</a>
    <a href="person1">Person 1</a>
    """
    return HttpResponse(string)
