from django.shortcuts import render, redirect
from .models import ExpenseForm, Expense
from django.contrib.auth.models import User
# Create your views here.
def addExpense(request):
    if request.method=="POST":
        uid=request.session.get("id")
        userobj=User.objects.get(id=uid)
        obj=ExpenseForm(request.POST)
        data=obj.save(commit=False)
        data.user=userobj
        obj.save()
        return redirect("/")
    else:
        d={"form":ExpenseForm}
        return render(request, "form.html", d)
    
    
def getExpense(request):
    uid=request.session.get("id")
    data=Expense.objects.filter(user=uid)
    print(data)
    d={"data":data}
    return render(request, "expense.html", d)

def deleteExpense(request, uid):
    obj=Expense.objects.get(id=uid)
    obj.delete()
    return redirect("/expense-del")

def editExpense(request, uid):
    obj=Expense.objects.get(id=uid)
    if request.method=="POST":
        user=ExpenseForm(request.POST, instance=obj)
        user.save()
        return redirect("expense.html")
    else:
        d={'form':ExpenseForm(instance=obj)}
        return render(request, "expense.html", d)
    
def search(request):
    searchdata=request.GET.get("searchdata")
    uid=request.session.get("id")
    data=Expense.objects.filter(user=uid, expense_desc__contains=searchdata)
    d={"data":data}
    return render(request, "expense.html",d)
