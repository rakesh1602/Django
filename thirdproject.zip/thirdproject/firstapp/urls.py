from django.urls import path
from . import views as v
urlpatterns = [
    path("",v.home),
    path("register",v.reg),
    path("register2",v.reg2),
    path("adddata",v.add),
    path("adddata2",v.add2),
    path("alluser",v.all)
]
