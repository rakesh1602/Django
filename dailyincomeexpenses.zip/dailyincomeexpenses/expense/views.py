from django.shortcuts import render, redirect
from .models import ExpenseForm, Expense

# Create your views here.
def addExpense(request):
    if request.method=="POST":
        obj=ExpenseForm(request.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":ExpenseForm}
        return render(request, "form.html", d)
    
    
def getExpense(request):
    data=Expense.objects.all()
    print(data)
    d={"data":data}
    return render(request, "expense.html", d)
