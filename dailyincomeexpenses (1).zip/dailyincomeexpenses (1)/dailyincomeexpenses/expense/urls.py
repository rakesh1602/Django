from django.urls import path
from . import views as v
urlpatterns = [
    path("-expense", v.addExpense, name="add"),
    path("-getexpense", v.getExpense, name="get"),
    path("-del/<int:uid>",v.deleteExpense,name="del"),
    path("-edit/<int:uid>",v.editExpense, name="edit"),
    path("-search",v.search, name="search")
]
