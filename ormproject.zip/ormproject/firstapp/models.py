from django.db import models

# Create your models here.

class Employee(models.Model):
    name=models.CharField(max_length=30)
    city=models.CharField(max_length=30)
    email=models.EmailField(max_length=50)
    password=models.CharField(max_length=30,null=True)
    
    def __str__(self):
        return str(self.id)+self.name
    
    class Meta:
        db_table="emp"

class Account(models.Model):
    salary=models.IntegerField()
    month=models.CharField(max_length=50)
    emp=models.ForeignKey(Employee, on_delete=models.CASCADE)
    
    class Meta:
        db_table="account"
        
        
class Academic(models.Model):
    ssc=models.FloatField()
    hsc=models.FloatField()
    emp=models.OneToOneField(Employee, on_delete=models.CASCADE)
    
    class Meta:
        db_table="academic"
        
class Academic2(Employee):
    ssc=models.FloatField()
    hsc=models.FloatField()
    
    class Meta:
        db_table="academic2"
        
class Projects(models.Model):
    projectName=models.CharField(max_length=40)
    price=models.IntegerField()
    emp=models.ManyToManyField(Employee)
    
    def getemp(s):
        l=",".join([str(i) for i in s.emp.all()])
        return l
    
    class Meta:
        db_table="project"
        
from django.contrib.auth.models import User

class Mytable(User):
    age=models.IntegerField()
    city=models.CharField(max_length=20)