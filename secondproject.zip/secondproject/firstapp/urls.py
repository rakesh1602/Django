
from django.contrib import admin
from django.urls import path
from .import views as v

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", v.home),
    path("person", v.person),
    path("person1", v.person1),
    path("person2", v.person2)
]
