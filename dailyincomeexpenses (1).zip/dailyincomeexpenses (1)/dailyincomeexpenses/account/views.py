from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
def home(r):
    return render(r,"home.html")

def reg(r):
    if r.method=="POST":
        obj=UserCreationForm(r.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":UserCreationForm}
        return render(r,"form.html",d)

from .models import *
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages as m
def userLogin(request):
    if request.method=="POST":
        username=request.POST.get("username")
        password=request.POST.get("password")
        user=authenticate(request,username=username,password=password)
        print(user)
        if user is not None:
            login(request, user)
            m.success(request, "Login successfull.")
            return redirect("/")
        else:
            m.warning(request, "Invalid username and password")
            d={"form":LoginForm}
            return render(request, "form.html",d)
    else:
        d={"form":LoginForm}
        return render(request, "form.html",d)
    
def userlogout(request):
    logout(request)
    m.success(request, "Logout successfull.")
    return redirect("/")