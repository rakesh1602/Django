from django.urls import path
from .import views as v

urlpatterns = [
    path("addimage",v.addimage),
    path("allimages",v.allimages)  
]