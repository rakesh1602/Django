from django.shortcuts import redirect, render
from .models import Imageform, Allimage

# Create your views here.

def addimage(r):
    if r.method=="POST":
        obj=Imageform(r.POST,r.FILES)
        obj.save()
        return redirect("/")
    else:
        d={"form":Imageform}
        return render(r, "form.html",d)

def allimages(r):
    data=Allimage.objects.all()
    d={"image":data}
    return render(r,"allimages.html",d)