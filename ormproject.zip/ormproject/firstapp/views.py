from django.shortcuts import render,redirect

# Create your views here.

def home(request):
    return render(request,"home.html")

from .models import Account, Employee, Academic, Projects
def adddata(request):
    if request.method=="POST":
        name=request.POST.get("name")
        city=request.POST.get("city")
        email=request.POST.get("email")
        password=request.POST.get("password")
        obj=Employee()
        obj.name=name
        obj.city=city
        obj.email=email
        obj.password=password
        obj.save()
        return redirect("/")

    else:
        return render(request,"register.html")
        
from .forms import Userform
def adddata2(request):
    if request.method=="POST":
        name=request.POST.get("name")
        city=request.POST.get("city")
        email=request.POST.get("email")
        password=request.POST.get("password")
        obj=Employee()
        obj.name=name
        obj.city=city
        obj.email=email
        obj.password=password
        obj.save()
        return redirect("/")

    else:
        d={"form":Userform}
        return render(request,"register2.html",d)
    
from .forms import Userform2, AccForm, AcademicForm, AcademicForm2, ProjectForm, Regform, Regform2, Regform3
def alldata3(request):
    if request.method=="POST":
        obj=Userform2(request.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":Userform2}
        return render(request,"register2.html",d)
    
def empdetails(request):
    data=Employee.objects.all()
    print(data)
    d={"data":data}
    return render(request,"empdetails.html",d)


def del1(request):
    uid=request.GET.get("id")
    obj=Employee.objects.get(id=uid)
    obj.delete()
    return redirect("/empdetails")

def del2(request,uid):
    obj=Employee.objects.get(id=uid)
    obj.delete()
    return redirect("/empdetails")

def edt(request,uid):
    obj=Employee.objects.get(id=uid)
    if request.method=="POST":
        user=Userform2(request.POST,instance=obj)
        user.save()
        return redirect("/empdetails")
    
    else:
        d={"form":Userform2(instance=obj)}
        return render(request,"register2.html",d)

def addacc(r):
    if r.method=="POST":
        obj=AccForm(r.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":AccForm}
        return render(r,"register2.html",d)
    
def accdetails(request):
    data=Account.objects.all()
    print(data)
    d={"account":data}
    return render(request,"accountdetails.html",d)
    
def delacc(r,uid):
    obj=Account.objects.get(id=uid)
    obj.delete()
    return redirect("/empdetails")

def edtacc(request,uid):
    obj=Account.objects.get(id=uid)
    if request.method=="POST":
        user=AccForm(request.POST,instance=obj)
        user.save()
        return redirect("/accountdetails.html")
    
    else:
        d={"form":AccForm(instance=obj)}
        return render(request,"register2.html",d)
    
def academic(request):
    if request.method=="POST":
        obj=AcademicForm(request.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":AcademicForm}
        return render(request,"register2.html",d)
    
def acddetails(request):
    data=Academic.objects.all()
    print(data)
    d={"academic":data}
    return render(request,"academic.html",d)
    
def delacd(r,uid):
    obj=Academic.objects.get(id=uid)
    obj.delete()
    return redirect("/academic.html")

def edtacd(request,uid):
    obj=Academic.objects.get(id=uid)
    if request.method=="POST":
        user=Academic(request.POST,instance=obj)
        user.save()
        return redirect("/academic.html")
    
def academic2(request):
    if request.method=="POST":
        obj=AcademicForm2(request.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":AcademicForm2}
        return render(request,"register2.html",d)
    
    
def projects(request):
    if request.method=="POST":
        obj=ProjectForm(request.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":ProjectForm}
        return render(request,"register2.html",d)
    
def prdetails(request):
    data=Projects.objects.all()
    print(data)
    d={"project":data}
    return render(request,"project.html",d)

#Authform


def reguser(r):
    if r.method=="POST":
        obj=Regform(r.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":Regform}
        return render(r,"register2.html",d)
    
def reguser2(r):
    if r.method=="POST":
        obj=Regform2(r.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":Regform2}
        return render(r,"register2.html",d)
    
from django.contrib.auth.forms import UserCreationForm
def reguser3(r):
    if r.method=="POST":
        obj=Regform3(r.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":Regform3}
        return render(r,"register2.html",d)
