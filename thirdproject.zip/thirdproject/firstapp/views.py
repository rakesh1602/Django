from django.shortcuts import render,HttpResponse,redirect
users=[]
# Create your views here.
def home(request):
    return render(request,"home.html")

def reg(request):
    return render(request,"register.html")    

def reg2(request):
    return render(request,"register2.html")

def add(request):
    name=request.GET.get("username")
    city=request.GET["usercity"]
    email=request.GET.get("useremail")
    password=request.GET.get("userpassword")
    t=(name,city,email,password)
    users.append(t)
    return HttpResponse("sucess")

def add2(request):
    name=request.POST.get("username")
    city=request.POST["usercity"]
    email=request.POST.get("useremail")
    password=request.POST.get("userpassword")
    t=(name,city,email,password)
    users.append(t)
    return HttpResponse("sucess")

def all(request):
    d={"alluser":users}
    return render(request,"details.html",d)