from django import forms

class UserForm(forms.Form):
    name = forms.CharField(max_length=40)
    city=forms.CharField(max_length=32)
    email=forms.EmailField(max_length=33)
    password = forms.CharField(max_length=40, widget= forms.PasswordInput)