from django.db import models

# Create your models here.
class Allimage(models.Model):
    name=models.CharField(max_length=40)
    image=models.ImageField(upload_to="secondapp_image")
    description=models.TextField(max_length=50)
    
    class Meta:
        db_table="allimages"

from django import forms

class Imageform(forms.ModelForm):
    class Meta:
        model=Allimage
        fields="__all__"