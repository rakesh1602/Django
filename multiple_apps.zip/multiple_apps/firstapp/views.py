from django.shortcuts import HttpResponse

def first(re):
    return HttpResponse("FIRST PAGE")
