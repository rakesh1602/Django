from django.shortcuts import render, redirect
from .models import IncomeForm, Income

# Create your views here.
def addIncome(request):
    if request.method=="POST":
        obj=IncomeForm(request.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":IncomeForm}
        return render(request, "form.html", d)
    
    
def getIncome(request):
    data=Income.objects.all()
    print(data)
    d={"data":data}
    return render(request, "incomes.html", d)

def editIncome(request, uid):
    obj=Income.objects.get(id=uid)
    if request.method=="POST":
        user=IncomeForm(request.POST,instance=obj)
        user.save()
        return redirect("income-edit")
    else:
        d={'form':IncomeForm(instance=obj)}
        return render(request,"incomes.html",d)

def delteIncome(request, uid):
    obj=Income.objects.get(id=uid)
    obj.delete()
    return redirect("/income-getincome")
    
