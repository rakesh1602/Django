from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
def home(r):
    return render(r,"home.html")

def reg(r):
    if r.method=="POST":
        obj=UserCreationForm(r.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":UserCreationForm}
        return render(r,"form.html",d)
        