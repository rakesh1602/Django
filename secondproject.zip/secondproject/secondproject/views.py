from django.shortcuts import HttpResponse

