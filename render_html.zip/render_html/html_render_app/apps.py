from django.apps import AppConfig


class HtmlRenderAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'html_render_app'
