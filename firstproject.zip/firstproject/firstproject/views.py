from django.shortcuts import HttpResponse

def home(request):
    string="""
    <h1>Home page</h1>
    <a href="second">second page</a><br>
    <a href="third">third page</a><br>
    """
    return HttpResponse(string)

def sec(r):
    string="""
    <h1>Second page</h1>
    <a href="/">home page</a><br>
    <a href="third">third page</a><br>
    """
    return HttpResponse(string)

def third(r):
    string="""
    <h1>Third page</h1>
    <a href="/">home page</a><br>
    <a href="second">second page</a><br>
    """
    return HttpResponse(string)

def fourth(r):
    return HttpResponse("welcome to fourth page")