from django.shortcuts import render, redirect

def home (request):
    return render(request, 'home.html')

from .models import Employee
def register(request):
    if request.method == 'POST':
        name=request.POST.get("username")
        city=request.POST.get("city")
        email=request.POST.get("email")
        password=request.POST.get("password")
        obj=Employee()
        obj.name=name
        obj.city=city
        obj.email=email
        obj.password=password
        obj.save()
        return redirect("/")
    else:
        return render(request, 'register2.html')
    

from .forms import UserForm
def formregister(request):
    if request.method == 'POST':
        name=request.POST.get("name")
        city=request.POST.get("city")
        email=request.POST.get("email")
        password=request.POST.get("password")
        obj=Employee()
        obj.name=name
        obj.city=city
        obj.email=email
        obj.password=password
        obj.save()
        return redirect("/")
    else:
        d={"form":UserForm}
        return render(request, 'register2.html',d)
        
    