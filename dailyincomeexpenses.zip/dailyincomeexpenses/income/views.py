from django.shortcuts import render, redirect
from .models import IncomeForm, Income

# Create your views here.
def addIncome(request):
    if request.method=="POST":
        obj=IncomeForm(request.POST)
        obj.save()
        return redirect("/")
    else:
        d={"form":IncomeForm}
        return render(request, "form.html", d)
    
    
def getIncome(request):
    data=Income.objects.all()
    print(data)
    d={"data":data}
    return render(request, "incomes.html", d)
