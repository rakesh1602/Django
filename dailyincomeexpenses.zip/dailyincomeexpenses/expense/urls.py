from django.urls import path
from . import views as v
urlpatterns = [
    path("-expense", v.addExpense, name="add"),
    path("-getexpense", v.getExpense, name="get")
]
