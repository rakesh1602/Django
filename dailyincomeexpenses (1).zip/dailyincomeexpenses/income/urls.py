from django.urls import path
from . import views as v
urlpatterns = [
    path("-income", v.addIncome, name="add"),
    path("-getincome", v.getIncome, name="get")
]
