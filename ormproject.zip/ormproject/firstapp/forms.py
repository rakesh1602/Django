from django import forms

class Userform(forms.Form):
    name=forms.CharField(max_length=40)
    city=forms.CharField(max_length=40)
    email=forms.CharField(max_length=40)
    password=forms.CharField(max_length=40,widget=forms.PasswordInput)

from .models import Employee, Account, Academic, Academic2, Projects, Mytable 
class Userform2(forms.ModelForm):
    class Meta:
        model=Employee
        fields="__all__"
        
class AccForm(forms.ModelForm):
    class Meta:
        model=Account
        fields="__all__"
        
class AcademicForm(forms.ModelForm):
    class Meta:
        model=Academic
        fields="__all__"
        
class AcademicForm2(forms.ModelForm):
    class Meta:
        model=Academic2
        fields="__all__"
        
class ProjectForm(forms.ModelForm):
    class Meta:
        model=Projects
        fields="__all__"
        
        
        #Auth forms
from django.contrib.auth.models import User

class Regform(forms.ModelForm):
    class Meta:
        model=User
        fields="__all__"
        
class Regform2(forms.ModelForm):
    class Meta:
        model=Mytable
        fields="__all__"
        
from django.contrib.auth.forms import UserCreationForm

class Regform3(UserCreationForm):
    class Meta:
        model=User
        fields=['username','email','date_joined']