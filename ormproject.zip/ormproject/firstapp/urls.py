from django.urls import path
from .import views as v

urlpatterns = [
    path("",v.home),
    path("reg",v.adddata),
    path("reg2",v.adddata2),
    path("reg3",v.alldata3),
    path("empdetails",v.empdetails),
    path("del1",v.del1),
    path("del2/<int:uid>",v.del2),
    path("edit/<int:uid>",v.edt),
    path("edit/<int:uid>",v.edt),
    path("addacc",v.addacc),
    path("viewacc",v.accdetails),
    path("del/<int:uid>", v.delacc),
    path("edit/<int:uid>",v.edtacc),
    path("academics", v.academic),
    path("all-academics",v.acddetails),
     path("del/<int:uid>", v.delacd),
    path("edit/<int:uid>",v.edtacd),
    path("edit/<int:uid>",v.edtacd),
    path("academic2", v.academic2),
    path("projects", v.projects),
    path("all-projects", v.prdetails),
    
    path("reguser", v.reguser),
    path("reguser2",v.reguser2),
    path("reguser3",v.reguser3)
    
]