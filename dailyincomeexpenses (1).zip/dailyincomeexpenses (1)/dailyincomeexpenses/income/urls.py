from django.urls import path
from . import views as v
urlpatterns = [
    path("-income", v.addIncome, name="add"),
    path("-getincome", v.getIncome, name="get"),
    path("-del/<int:uid>",v.delteIncome,name="delincome"),
    path("-edit/<int:uid>",v.editIncome, name="edit"),
    path("-search",v.search, name="search"),
    path("-sort/<type>",v.sort, name="sort")
]
