from django.shortcuts import render, redirect
from .models import IncomeForm, Income
from django.contrib.auth.models import User

# Create your views here.
def addIncome(request):
    if request.method=="POST":
        uid=request.session.get("id")
        userobj=User.objects.get(id=uid)
        obj=IncomeForm(request.POST)
        data=obj.save(commit=False)
        data.user=userobj
        data.save()
        return redirect("/")
    else:
        d={"form":IncomeForm}
        return render(request, "form.html", d)
    
def getIncome(request):
    uid=request.session.get("id")
    data=Income.objects.filter(user=uid)
    print(data)
    d={"data":data}
    return render(request, "incomes.html", d)

def editIncome(request, uid):
    obj=Income.objects.get(id=uid)
    if request.method=="POST":
        user=IncomeForm(request.POST,instance=obj)
        user.save()
        return redirect("income-edit")
    else:
        d={'form':IncomeForm(instance=obj)}
        return render(request,"incomes.html",d)

def delteIncome(request, uid):
    obj=Income.objects.get(id=uid)
    obj.delete()
    return redirect("/income-getincome")

def search(request):
    searchdata=request.GET.get("searchdata")
    uid=request.session.get("id")
    data=Income.objects.filter(user=uid, income_desc__contains=searchdata)
    d={"data":data}
    return render(request, "incomes.html",d)

def sort(request, type):
    uid=request.session.get("id")
    print("user id", uid)
    data=Income.objects.filter(user=uid, income_type=type)
    alldata=Income.objects.filter(user=uid)
    print("data present",data)
    incomelist=set()
    for i in alldata:
        incomelist.add(i.income_type)
    d={"data":data, "incomelist":incomelist}
    return render(request, "incomes.html",d)
    