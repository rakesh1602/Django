from django.shortcuts import render, redirect


def home(r):
    return render(r, "home.html")

def reg(r):
    return render(r, "register.html")

def getdata(r):
    username=r.GET["username"]
    password=r.GET["password"]
    email=r.GET["email"]
    t=(username,password,email)
    print(t)
    return redirect("/")
