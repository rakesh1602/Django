from django.shortcuts import HttpResponse

def second(r):
    return HttpResponse("SECOND PAGE")
